// Back to Top Button Functionality
const backToTop = document.getElementById('back-to-top');

// Show/Hide Back to Top Button
window.addEventListener('scroll', () => {
    if (window.scrollY > window.innerHeight) {
        backToTop.style.display = 'block';
    } else {
        backToTop.style.display = 'none';
    }
});

// Scroll Back top
backToTop.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth',
    });
});