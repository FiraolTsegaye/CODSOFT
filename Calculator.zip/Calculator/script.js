let input = document.getElementById('inputBox');
let buttons = document.querySelectorAll('button');

let string = "";
let arr = Array.from(buttons);
arr.forEach(button => {
    button.addEventListener('click', (e) => {
        if (e.target.innerHTML == '=') {
            try {
                string = eval(string);
                string = string.toString(); // Ensure the result is a string
                input.value = string;
            } catch (error) {
                input.value = 'Error';
                string = '';
            }
        } 
        else if (e.target.innerHTML == 'AC') {
            string = "";
            input.value = string;
        }
        else if (e.target.innerHTML == 'DEL') {
            const cursorPos = input.selectionStart;
            if (cursorPos > 0) {
                // Remove character before cursor
                string = string.slice(0, cursorPos - 1) + string.slice(cursorPos);
                input.value = string;
                input.setSelectionRange(cursorPos - 1, cursorPos - 1); // Maintain cursor position
            }
        } 
        else {
            const cursorPos = input.selectionStart;
            // Insert the button value at the cursor position
            string = string.slice(0, cursorPos) + e.target.innerHTML + string.slice(cursorPos);
            input.value = string;
            input.setSelectionRange(cursorPos + 1, cursorPos + 1); // Move the cursor after the inserted character
        }
    });
});